import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, CheckCircle2, Clock, Lock, Unlock, Hand, GraduationCap, Timer } from 'lucide-react';
import { t } from '../lib/i18n';
import { playSound, triggerHaptic } from '../lib/sound';

export default function UserGuideScreen({ onClose, theme, language, sound, haptics }: { onClose: () => void, theme: string, language: string, sound: boolean, haptics: boolean }) {
  const handleClose = () => {
    playSound('click', sound);
    triggerHaptic('light', haptics);
    onClose();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className={`fixed inset-0 z-50 overflow-y-auto p-6 sm:p-12 ${
        theme === 'dark' ? 'bg-neutral-900 text-white' : 
        theme === 'eyecare' ? 'bg-[#fdf6e3] text-[#5c4d3c]' :
        theme === 'grayscale' ? 'bg-[#f0f0f0] text-[#222222] grayscale' :
        theme === 'glass' ? 'bg-white/40 backdrop-blur-2xl text-neutral-800' :
        'bg-[#fafafa] text-neutral-800'
      }`}
    >
      <div className="max-w-2xl mx-auto pb-32">
        <button onClick={handleClose} className="flex items-center mb-12 opacity-70 hover:opacity-100 transition-opacity">
          <ArrowLeft size={20} className="mr-2" /> {t(language, 'back')}
        </button>

        <h1 className="text-4xl font-medium tracking-tight mb-4">{t(language, 'userGuide')}</h1>
        <p className="opacity-60 mb-12 text-lg">{t(language, 'guideSubtitle')}</p>

        <div className="space-y-12">
          <section>
            <div className="flex items-center mb-4 text-emerald-500">
              <Hand size={28} className="mr-3" />
              <h2 className="text-2xl font-medium">{t(language, 'guideOpenTodo')}</h2>
            </div>
            <p className="opacity-80 leading-relaxed text-lg bg-black/5 dark:bg-white/5 p-6 rounded-2xl">
              {t(language, 'guideOpenTodoDesc')}
            </p>
          </section>

          <section>
            <div className="flex items-center mb-4 text-emerald-500">
              <CheckCircle2 size={28} className="mr-3" />
              <h2 className="text-2xl font-medium">{t(language, 'guideTaskCompletion')}</h2>
            </div>
            <p className="opacity-80 leading-relaxed text-lg bg-black/5 dark:bg-white/5 p-6 rounded-2xl">
              {t(language, 'guideTaskCompletionDesc')}
            </p>
          </section>

          <section>
            <div className="flex items-center mb-4 text-emerald-500">
              <Clock size={28} className="mr-3" />
              <h2 className="text-2xl font-medium">{t(language, 'guideTimer')}</h2>
            </div>
            <p className="opacity-80 leading-relaxed text-lg bg-black/5 dark:bg-white/5 p-6 rounded-2xl">
              {t(language, 'guideTimerDesc')}
            </p>
          </section>

          <section>
            <div className="flex items-center mb-4 text-emerald-500">
              <Lock size={28} className="mr-3" />
              <h2 className="text-2xl font-medium">{t(language, 'guideUnlock')}</h2>
            </div>
            <p className="opacity-80 leading-relaxed text-lg bg-black/5 dark:bg-white/5 p-6 rounded-2xl">
              {t(language, 'guideUnlockDesc')}
            </p>
          </section>

          <section>
            <div className="flex items-center mb-4 text-emerald-500">
              <GraduationCap size={28} className="mr-3" />
              <h2 className="text-2xl font-medium">{t(language, 'studentZone')}</h2>
            </div>
            <div className="opacity-80 leading-relaxed text-lg bg-black/5 dark:bg-white/5 p-6 rounded-2xl space-y-4">
              <p>{t(language, 'guideStudentZoneDesc')}</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>{t(language, 'guideAddExamDesc')}</li>
                <li>{t(language, 'guideLongPressDesc')}</li>
              </ul>
            </div>
          </section>

          <section>
            <div className="flex items-center mb-4 text-emerald-500">
              <Timer size={28} className="mr-3" />
              <h2 className="text-2xl font-medium">{t(language, 'focusTimer')}</h2>
            </div>
            <p className="opacity-80 leading-relaxed text-lg bg-black/5 dark:bg-white/5 p-6 rounded-2xl">
              {t(language, 'guideFocusTimerDesc')}
            </p>
          </section>

          <section>
            <div className="flex items-center mb-4 text-emerald-500">
              <div className="w-7 h-7 rounded-full border-2 border-emerald-500 mr-3 flex items-center justify-center">✨</div>
              <h2 className="text-2xl font-medium">{t(language, 'glassMode')}</h2>
            </div>
            <p className="opacity-80 leading-relaxed text-lg bg-black/5 dark:bg-white/5 p-6 rounded-2xl">
              {t(language, 'guideGlassModeDesc')}
            </p>
          </section>
        </div>
      </div>
    </motion.div>
  );
}
